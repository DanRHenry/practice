const placeholderQuestions = require('./placeholder-questions')

